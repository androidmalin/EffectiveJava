// object/HelloDocTest.java
// TIJ4 Chapter Object, Exercies 15, page 91
/* Take the program in Exercise 2 and add comment documentation to it. Extract
* this comment documentation into an HTML file using Javadoc and view it with
* your Web browser.
*/


/** 
* Public class contained in file of the same name that includes main()
*/

public class HelloDocTest {

	/** main method executed by java
	*/	

	public static void main(String[] args) {
	System.out.println("Hello World!");
	}
}